<?php
include_once ("interfaces/DeplacementInterface.php");

class Voiture implements DeplacementInterface {

    public function seDeplacer()
    {
        echo "Rouler";
    }

    public function recharger()
    {
        echo "Faire le plein";
    }
}