<?php
include_once("interfaces/SpeciesInterface.php");
include_once("interfaces/DeplacementInterface.php");

class Personne implements SpeciesInterface, DeplacementInterface
{

    public function getName()
    {
        echo "Valentin Brosseau";
    }

    public function getAge()
    {
        echo 34;
    }

    public function seDeplacer()
    {
        echo "Marcher";
    }

    public function recharger()
    {
        echo "Manger";
    }
}

class Chien implements SpeciesInterface, DeplacementInterface
{

    public function getName()
    {
        echo "Le chien";
    }

    public function getAge()
    {
        echo 10;
    }

    public function seDeplacer()
    {
        echo "Courir";
    }

    public function recharger()
    {
        echo "Manger";
    }
}