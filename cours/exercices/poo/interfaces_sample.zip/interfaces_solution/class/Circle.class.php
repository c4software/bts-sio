<?php
include_once("IISurface.php");

class Circle implements IISurface
{
    private $r = 0;

    public function __construct($r)
    {
        $this->r = $r;
    }

    public function surface(): int
    {
        return pi() * ($this->r * $this->r);
    }
}