<?php
include_once("IISurface.php");

class Square implements IISurface
{
    private $longueur = 0;

    public function __construct($longueur)
    {
        $this->longueur = $longueur;
    }

    public function surface(): int
    {
        return ($this->longueur * $this->longueur);
    }
}