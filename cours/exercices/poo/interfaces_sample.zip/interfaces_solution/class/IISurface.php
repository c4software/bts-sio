<?php

interface IISurface
{
    public function surface(): int;
}