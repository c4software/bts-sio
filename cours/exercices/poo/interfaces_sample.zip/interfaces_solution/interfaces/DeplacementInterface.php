<?php

interface DeplacementInterface{
    public function seDeplacer();
    public function recharger();
}