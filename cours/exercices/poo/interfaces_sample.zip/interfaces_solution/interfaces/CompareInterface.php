<?php

interface CompareInterface{
    public function compareTo(CompareInterface $obj);
}