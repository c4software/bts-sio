<?php

interface SpeciesInterface{
    public function getName();
    public function getAge();
}