<?php

function calculateSurfaceOf(Array $arr){
    foreach ($arr as $a){
        if($a instanceof IISurface) {
            echo "La surface est de {$a->surface()}<br />";
        } else {
            echo "La class n'implémente pas l'interface « Surface »";
        }
    }
}