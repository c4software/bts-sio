<?php
include_once ("./class/Circle.class.php");
include_once ("./class/Square.class.php");
include_once ("./utils/index.php");

calculateSurfaceOf([new Circle(10), new Square(10)]);