<?php

namespace controllers\base;

interface IBase
{
    function redirect($to);
}