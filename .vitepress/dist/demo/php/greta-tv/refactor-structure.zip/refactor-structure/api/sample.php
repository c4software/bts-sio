<?php

echo json_encode(array("Ceci est un exemple", "de", "tableau"));