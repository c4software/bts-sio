<?php

namespace controllers\base;

class Api implements IBase
{

    function redirect($to)
    {
        // Do Nothing
    }
}