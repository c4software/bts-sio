<?php

$DB_SERVER = "127.0.0.1";
$DB_DATABASE = "GretaTV";
$DB_USER = "root";
$DB_PASSWORD = "";

$DB_DSN = "mysql:host=$DB_SERVER;dbname=$DB_DATABASE";
