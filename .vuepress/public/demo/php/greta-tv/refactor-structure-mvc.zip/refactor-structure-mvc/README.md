# Structure MVC

Cette structure est réalisée à des fins pédagogiques. Elle est un intermédiaire permettant d'introduire les concepts du
framework Laravel sur des bases de développement PHP connu.

[Document associé disponible ici](https://cours.brosseau.ovh/tp/php/mvc/tp1.html)
