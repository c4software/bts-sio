<div class="frame">
    <iframe width="560" height="315" src="https://www.youtube.com/embed/<?= $video['videoId']; ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<div class="stand"><?= $video['name'] ?></div>