import Vue from 'vue';
import messageDialog from 'vuetify-vuejs-messagedialog';

Vue.use(messageDialog);