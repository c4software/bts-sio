package com.example.plugins

import com.example.room.roomRoutes
import com.example.sensor.sensorRoutes
import io.ktor.server.application.Application
import io.ktor.server.response.respondText
import io.ktor.server.routing.get
import io.ktor.server.routing.route
import io.ktor.server.routing.routing

fun Application.configureRouting() {
    routing {
        get("/") {
            call.respondText("L'API Capteurs fonctionne !")
        }
        route("/v1") {
            sensorRoutes()
            roomRoutes()
        }
    }
}
