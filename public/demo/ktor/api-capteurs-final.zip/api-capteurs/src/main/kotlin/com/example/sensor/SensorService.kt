package com.example.sensor

import com.example.common.ApiException
import io.ktor.http.HttpStatusCode

class SensorService(private val sensorDao: SensorDao) {

    fun getAll(): List<Sensor> = sensorDao.findAll()

    fun getById(id: Int): Sensor =
        sensorDao.findById(id) ?: throw notFound(id)

    fun create(request: SensorRequest): Sensor {
        request.validate()
        return sensorDao.create(request)
    }

    fun update(id: Int, request: SensorRequest): Sensor {
        request.validate()
        return sensorDao.update(id, request) ?: throw notFound(id)
    }

    fun delete(id: Int) {
        if (!sensorDao.delete(id)) throw notFound(id)
    }

    private fun notFound(id: Int) = ApiException(HttpStatusCode.NotFound, "Le capteur $id n'existe pas")
}
