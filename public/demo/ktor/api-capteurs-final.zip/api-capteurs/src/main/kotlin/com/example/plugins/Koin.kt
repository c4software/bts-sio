package com.example.plugins

import com.example.room.roomModule
import com.example.security.securityModule
import com.example.sensor.sensorModule
import io.ktor.server.application.Application
import io.ktor.server.application.install
import org.koin.ktor.plugin.Koin
import org.koin.logger.slf4jLogger

fun Application.configureKoin() {
    install(Koin) {
        slf4jLogger()
        modules(sensorModule, roomModule, securityModule)
    }
}
