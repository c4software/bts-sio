package cours.brosseau.plugins

import cours.brosseau.measure.measureModule
import cours.brosseau.room.roomModule
import cours.brosseau.security.securityModule
import cours.brosseau.sensor.sensorModule
import io.ktor.server.application.Application
import io.ktor.server.application.install
import org.koin.ktor.plugin.Koin
import org.koin.logger.slf4jLogger

fun Application.configureKoin() {
    install(Koin) {
        slf4jLogger()
        modules(sensorModule, measureModule, roomModule, securityModule)
    }
}
