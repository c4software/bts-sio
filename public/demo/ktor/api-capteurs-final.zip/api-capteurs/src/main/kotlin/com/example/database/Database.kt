package com.example.database

import com.zaxxer.hikari.HikariConfig
import com.zaxxer.hikari.HikariDataSource
import io.ktor.server.application.Application
import io.ktor.server.application.ApplicationStopped
import org.flywaydb.core.Flyway
import org.jetbrains.exposed.v1.jdbc.Database

fun Application.configureDatabase() {
    val config = environment.config

    // 1. Le pool de connexions
    val dataSource = HikariDataSource(HikariConfig().apply {
        jdbcUrl = config.property("database.url").getString()
        username = config.property("database.user").getString()
        password = config.property("database.password").getString()
        maximumPoolSize = 5
    })

    // 2. Les migrations
    Flyway.configure()
        .dataSource(dataSource)
        .load()
        .migrate()

    // 3. Exposed utilisera ce pool pour toutes ses requêtes
    Database.connect(dataSource)

    // 4. On ferme proprement le pool quand le serveur s'arrête
    monitor.subscribe(ApplicationStopped) {
        dataSource.close()
    }
}
