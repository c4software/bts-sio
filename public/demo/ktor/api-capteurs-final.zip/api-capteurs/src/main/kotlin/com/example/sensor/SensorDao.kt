package com.example.sensor

import org.jetbrains.exposed.v1.core.ResultRow
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insert
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update

interface SensorDao {
    fun findAll(): List<Sensor>
    fun findById(id: Int): Sensor?
    fun create(request: SensorRequest): Sensor
    fun update(id: Int, request: SensorRequest): Sensor?
    fun delete(id: Int): Boolean
}

class ExposedSensorDao : SensorDao {

    override fun findAll(): List<Sensor> = transaction {
        SensorTable.selectAll()
            .orderBy(SensorTable.id)
            .map { it.toSensor() }
    }

    override fun findById(id: Int): Sensor? = transaction {
        SensorTable.selectAll()
            .where { SensorTable.id eq id }
            .map { it.toSensor() }
            .singleOrNull()
    }

    override fun create(request: SensorRequest): Sensor = transaction {
        val newId = SensorTable.insert {
            it[SensorTable.name] = request.name
            it[SensorTable.type] = request.type
            it[SensorTable.unit] = request.unit
            it[SensorTable.active] = request.active
        }[SensorTable.id]

        Sensor(newId, request.name, request.type, request.unit, request.active)
    }

    override fun update(id: Int, request: SensorRequest): Sensor? = transaction {
        val updatedRows = SensorTable.update({ SensorTable.id eq id }) {
            it[SensorTable.name] = request.name
            it[SensorTable.type] = request.type
            it[SensorTable.unit] = request.unit
            it[SensorTable.active] = request.active
        }

        if (updatedRows == 0) null else Sensor(id, request.name, request.type, request.unit, request.active)
    }

    override fun delete(id: Int): Boolean = transaction {
        SensorTable.deleteWhere { SensorTable.id eq id } > 0
    }

    // Transforme une ligne de la base en objet Sensor
    private fun ResultRow.toSensor() = Sensor(
        id = this[SensorTable.id],
        name = this[SensorTable.name],
        type = this[SensorTable.type],
        unit = this[SensorTable.unit],
        active = this[SensorTable.active]
    )
}
