CREATE TABLE capteur (
    id     SERIAL PRIMARY KEY,
    nom    VARCHAR(100) NOT NULL,
    type   VARCHAR(30)  NOT NULL,
    unite  VARCHAR(10)  NOT NULL,
    actif  BOOLEAN      NOT NULL DEFAULT TRUE
);

INSERT INTO capteur (nom, type, unite) VALUES
    ('Salle serveur', 'temperature', '°C'),
    ('Atelier', 'humidite', '%'),
    ('Salle de réunion', 'co2', 'ppm');
