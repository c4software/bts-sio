package cours.brosseau.sensor

import org.jetbrains.exposed.v1.core.ResultRow
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction

interface SensorDao {
    fun findAll(): List<Sensor>
}

class ExposedSensorDao : SensorDao {

    override fun findAll(): List<Sensor> = transaction {
        SensorTable.selectAll()
            .orderBy(SensorTable.id)
            .map { it.toSensor() }
    }

    // Transforme une ligne de la base en objet Sensor
    private fun ResultRow.toSensor() = Sensor(
        id = this[SensorTable.id],
        name = this[SensorTable.name],
        type = this[SensorTable.type],
        unit = this[SensorTable.unit],
        active = this[SensorTable.active]
    )
}
