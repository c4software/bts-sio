package cours.brosseau.lampadaires.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import cours.brosseau.lampadaires.ui.creation.CreationScreen
import cours.brosseau.lampadaires.ui.detail.DetailScreen
import cours.brosseau.lampadaires.ui.liste.ListeScreen

/**
 * La navigation de l'application : la liste, le détail d'un lampadaire, la création.
 */
@Composable
fun LampadairesApp() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "liste") {
        composable("liste") {
            ListeScreen(
                onLampadaireClick = { id -> navController.navigate("detail/$id") },
                onAjouterClick = { navController.navigate("creation") },
            )
        }
        composable(
            route = "detail/{id}",
            arguments = listOf(navArgument("id") { type = NavType.IntType }),
        ) { entry ->
            DetailScreen(
                id = entry.arguments?.getInt("id") ?: 0,
                onRetour = { navController.navigateUp() },
            )
        }
        composable("creation") {
            CreationScreen(onRetour = { navController.navigateUp() })
        }
    }
}
