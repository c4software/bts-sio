package cours.brosseau.sensor

import org.jetbrains.exposed.v1.core.Table

object SensorTable : Table("capteur") {
    val id = integer("id").autoIncrement()
    val name = varchar("nom", 100)
    val type = varchar("type", 30)
    val unit = varchar("unite", 10)
    val active = bool("actif")

    override val primaryKey = PrimaryKey(id)
}
