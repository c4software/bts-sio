package cours.brosseau.measure

import cours.brosseau.sensor.SensorService

class MeasureService(
    private val measureDao: MeasureDao,
    private val sensorService: SensorService
) {

    fun getBySensor(sensorId: Int): List<Measure> {
        // Lève une 404 si le capteur n'existe pas
        sensorService.getById(sensorId)
        return measureDao.findBySensor(sensorId)
    }
}
