package cours.brosseau.measure

import kotlinx.serialization.Serializable

// Une mesure, accompagnée du nom et de l'unité de son capteur
@Serializable
data class Measure(
    val id: Int,
    val sensor: String,
    val value: Double,
    val unit: String
)
