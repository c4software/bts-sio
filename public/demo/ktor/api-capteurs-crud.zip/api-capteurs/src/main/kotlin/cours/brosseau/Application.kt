package cours.brosseau

import cours.brosseau.database.configureDatabase
import cours.brosseau.plugins.configureErrorHandling
import cours.brosseau.plugins.configureKoin
import cours.brosseau.plugins.configureRouting
import cours.brosseau.plugins.configureSerialization
import io.ktor.server.application.Application
import io.ktor.server.netty.EngineMain

fun main(args: Array<String>) {
    EngineMain.main(args)
}

fun Application.module() {
    configureKoin()
    configureDatabase()
    configureSerialization()
    configureErrorHandling()
    configureRouting()
}
