package cours.brosseau.measure

import cours.brosseau.sensor.SensorTable
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction

interface MeasureDao {
    fun findBySensor(sensorId: Int): List<Measure>
}

class ExposedMeasureDao : MeasureDao {

    override fun findBySensor(sensorId: Int): List<Measure> = transaction {
        (MeasureTable innerJoin SensorTable)
            .selectAll()
            .where { MeasureTable.sensorId eq sensorId }
            .orderBy(MeasureTable.id)
            .map {
                Measure(
                    id = it[MeasureTable.id],
                    sensor = it[SensorTable.name],
                    value = it[MeasureTable.value],
                    unit = it[SensorTable.unit]
                )
            }
    }
}
