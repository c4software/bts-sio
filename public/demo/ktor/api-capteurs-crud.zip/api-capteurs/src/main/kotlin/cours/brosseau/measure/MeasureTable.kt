package cours.brosseau.measure

import cours.brosseau.sensor.SensorTable
import org.jetbrains.exposed.v1.core.Table

object MeasureTable : Table("mesure") {
    val id = integer("id").autoIncrement()
    val sensorId = reference("capteur_id", SensorTable.id)
    val value = double("valeur")

    override val primaryKey = PrimaryKey(id)
}
