package cours.brosseau.measure

import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module

val measureModule = module {
    singleOf(::ExposedMeasureDao) bind MeasureDao::class
    singleOf(::MeasureService)
}
