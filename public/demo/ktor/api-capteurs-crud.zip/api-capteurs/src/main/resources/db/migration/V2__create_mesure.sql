CREATE TABLE mesure (
    id          SERIAL PRIMARY KEY,
    capteur_id  INTEGER          NOT NULL REFERENCES capteur (id) ON DELETE CASCADE,
    valeur      DOUBLE PRECISION NOT NULL
);

-- Quelques mesures de départ : on retrouve le capteur par son nom, plutôt que d'écrire son identifiant en dur
INSERT INTO mesure (capteur_id, valeur) SELECT id, 21.5 FROM capteur WHERE nom = 'Salle serveur';
INSERT INTO mesure (capteur_id, valeur) SELECT id, 22.1 FROM capteur WHERE nom = 'Salle serveur';
INSERT INTO mesure (capteur_id, valeur) SELECT id, 23.4 FROM capteur WHERE nom = 'Salle serveur';
INSERT INTO mesure (capteur_id, valeur) SELECT id, 48.0 FROM capteur WHERE nom = 'Atelier';
INSERT INTO mesure (capteur_id, valeur) SELECT id, 51.5 FROM capteur WHERE nom = 'Atelier';
