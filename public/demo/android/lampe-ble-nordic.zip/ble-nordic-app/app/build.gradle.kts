plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

android {
    namespace = "fr.playmoweb.blenordic"
    compileSdk = 37

    defaultConfig {
        applicationId = "fr.playmoweb.blenordic"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        // Adresse de la lampe en Wi-Fi (HTTP) : l'adresse IP du PC qui fait tourner l'émulateur,
        // ou celle de la carte ESP32. Le port est celui du tableau de bord de l'émulateur (8080).
        buildConfigField("String", "LAMPE_URL", "\"http://192.168.1.27:8080\"")
    }

    // Deux variantes de l'application :
    //  - "native" : le vrai Bluetooth du téléphone et le vrai réseau (la lampe ou son émulateur) ;
    //  - "mock"   : une lampe simulée, pour travailler sur l'émulateur Android (ni Bluetooth, ni lampe).
    // Seuls ble/CentralManagerFactory.kt et http/HttpClientFactory.kt diffèrent entre les deux.
    flavorDimensions += "mode"
    productFlavors {
        create("native") {
            dimension = "mode"
            isDefault = true
        }
        create("mock") {
            dimension = "mode"
            applicationIdSuffix = ".mock"
            // Adresse fictive : en mode simulé, aucune requête ne quitte le téléphone
            buildConfigField("String", "LAMPE_URL", "\"http://lampe.simulee\"")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    // Bibliothèque BLE de Nordic : implémentation réelle ou simulée selon la variante.
    "nativeImplementation"(libs.nordic.ble.client.android)
    "mockImplementation"(libs.nordic.ble.client.android.mock)

    // Ktor : client HTTP, JSON, et moteur réel (OkHttp) ou simulé (MockEngine) selon la variante
    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.content.negotiation)
    implementation(libs.ktor.serialization.kotlinx.json)
    implementation(libs.kotlinx.serialization.json)
    "nativeImplementation"(libs.ktor.client.okhttp)
    "mockImplementation"(libs.ktor.client.mock)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.compose.ui.tooling.preview)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    implementation(libs.accompanist.permissions)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.compose.material.icons.extended)
}
