plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "fr.playmoweb.blenordic"
    compileSdk = 37

    defaultConfig {
        applicationId = "fr.playmoweb.blenordic"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"
    }

    // Deux variantes de l'application :
    //  - "native" : la vraie pile Bluetooth du téléphone (celle à utiliser avec l'ESP32) ;
    //  - "mock"   : une lampe simulée, pour travailler sur l'émulateur (pas de Bluetooth).
    // Seul le fichier ble/CentralManagerFactory.kt diffère entre les deux.
    flavorDimensions += "mode"
    productFlavors {
        create("native") {
            dimension = "mode"
            isDefault = true
        }
        create("mock") {
            dimension = "mode"
            applicationIdSuffix = ".mock"
        }
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // Bibliothèque BLE de Nordic : implémentation réelle ou simulée selon la variante.
    "nativeImplementation"(libs.nordic.ble.client.android)
    "mockImplementation"(libs.nordic.ble.client.android.mock)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.compose.ui.tooling.preview)
    debugImplementation(libs.compose.ui.tooling)

    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    implementation(libs.accompanist.permissions)
}
