package fr.playmoweb.blenordic.model

/**
 * La machine à états de l'écran Bluetooth.
 *
 * La vue fait un `when` sur cet état : à chaque état, son composant.
 */
sealed interface EcranBle {
    /** Liste des appareils, scan en cours ou non. */
    data object Scan : EcranBle

    /** Connexion en cours (loader). */
    data class Connexion(val nom: String) : EcranBle

    /** Connecté : l'état de la LED et le compteur arrivent par notification. */
    data class Connecte(
        val nom: String,
        val ledAllumee: Boolean? = null, // null tant qu'aucune notification n'est reçue
        val compteur: Int? = null,
    ) : EcranBle
}
