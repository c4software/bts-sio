package fr.playmoweb.blenordic.ui.http

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import fr.playmoweb.blenordic.model.EcranHttp
import fr.playmoweb.blenordic.model.StatutLampe
import fr.playmoweb.blenordic.ui.components.Chargement
import fr.playmoweb.blenordic.ui.components.EtatLampe
import fr.playmoweb.blenordic.ui.components.MessageErreur

/**
 * L'écran Wi-Fi : la même lampe, pilotée en HTTP. Une machine à états, comme l'écran Bluetooth.
 */
@Composable
fun HttpScreen(viewModel: HttpViewModel = viewModel()) {
    val ecran by viewModel.ecran.collectAsStateWithLifecycle()

    when (val etat = ecran) {
        EcranHttp.Chargement -> Chargement("Requête vers ${viewModel.adresse}…")
        is EcranHttp.Lampe -> LampeHttp(
            adresse = viewModel.adresse,
            statut = etat.statut,
            onBasculer = viewModel::basculer,
            onActualiser = viewModel::actualiser,
        )
        is EcranHttp.Erreur -> ErreurHttp(message = etat.message, onReessayer = viewModel::actualiser)
    }
}

@Composable
private fun LampeHttp(adresse: String, statut: StatutLampe, onBasculer: () -> Unit, onActualiser: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Lampe sur $adresse", style = MaterialTheme.typography.titleMedium)
        EtatLampe(ledAllumee = statut.ledAllumee, compteur = statut.count)
        Button(onClick = onBasculer, modifier = Modifier.fillMaxWidth()) { Text("Basculer la LED (/toggle)") }
        OutlinedButton(onClick = onActualiser, modifier = Modifier.fillMaxWidth()) { Text("Actualiser (/status)") }
        Text(
            "En HTTP, la lampe ne prévient pas : l'état affiché est celui de la dernière requête.",
            style = MaterialTheme.typography.bodySmall,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun ErreurHttp(message: String, onReessayer: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        MessageErreur(message)
        Text(
            "Vérifiez que le téléphone et la lampe sont sur le même réseau, et l'adresse LAMPE_URL dans build.gradle.kts.",
            textAlign = TextAlign.Center,
        )
        Button(onClick = onReessayer) { Text("Réessayer") }
    }
}
