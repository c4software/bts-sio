package fr.playmoweb.blenordic.model

import kotlinx.serialization.Serializable

/**
 * Réponse de la lampe en HTTP, sur /status et /toggle : {"state": "ON", "count": 3}
 */
@Serializable
data class StatutLampe(val state: String, val count: Int) {
    val ledAllumee: Boolean get() = state == "ON"
}
