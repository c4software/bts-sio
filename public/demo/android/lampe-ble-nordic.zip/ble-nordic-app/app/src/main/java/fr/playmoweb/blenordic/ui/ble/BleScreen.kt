package fr.playmoweb.blenordic.ui.ble

import android.Manifest
import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import fr.playmoweb.blenordic.model.EcranBle
import fr.playmoweb.blenordic.ui.components.Chargement

/** Permissions nécessaires au BLE, selon la version d'Android. */
private val permissionsBle: List<String> =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        listOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

/**
 * L'écran Bluetooth : une machine à états.
 * La vue écoute l'état du ViewModel et affiche, pour chaque état, le composant qui lui correspond.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun BleScreen(viewModel: LampeViewModel = viewModel()) {
    val permissions = rememberMultiplePermissionsState(permissionsBle)

    // Les StateFlow du ViewModel deviennent des états Compose
    val ecran by viewModel.ecran.collectAsStateWithLifecycle()
    val appareils by viewModel.appareils.collectAsStateWithLifecycle()
    val scanEnCours by viewModel.scanEnCours.collectAsStateWithLifecycle()
    val erreur by viewModel.erreur.collectAsStateWithLifecycle()

    if (!permissions.allPermissionsGranted) {
        PermissionsScreen(onDemander = { permissions.launchMultiplePermissionRequest() })
        return
    }

    when (val etat = ecran) {
        EcranBle.Scan -> ScanScreen(
            appareils = appareils,
            scanEnCours = scanEnCours,
            erreur = erreur,
            onScan = viewModel::demarrerScan,
            onStop = viewModel::arreterScan,
            onClicAppareil = viewModel::connecter,
        )
        is EcranBle.Connexion -> Chargement("Connexion à ${etat.nom}…")
        is EcranBle.Connecte -> ConnectedScreen(
            etat = etat,
            erreur = erreur,
            onBasculer = viewModel::basculerLed,
            onRenommer = viewModel::renommer,
            onDeconnecter = viewModel::deconnecter,
        )
    }
}
