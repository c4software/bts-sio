package fr.playmoweb.blenordic.model

import no.nordicsemi.kotlin.ble.client.android.Peripheral

/** Un appareil trouvé pendant le scan. */
data class Appareil(val nom: String, val adresse: String, val peripheral: Peripheral)
