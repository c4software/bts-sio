package fr.playmoweb.blenordic.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** L'« ampoule » : un disque jaune si la LED est allumée, gris sinon, très clair si l'état est inconnu. */
@Composable
fun LedIndicator(ledAllumee: Boolean?, modifier: Modifier = Modifier) {
    val couleur = when (ledAllumee) {
        true -> Color(0xFFFFC107)
        false -> Color(0xFFBDBDBD)
        null -> Color(0xFFEEEEEE)
    }
    Box(modifier.size(140.dp).background(couleur, CircleShape).border(3.dp, Color(0xFF616161), CircleShape))
}
