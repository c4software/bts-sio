package fr.playmoweb.blenordic.http

import fr.playmoweb.blenordic.model.StatutLampe
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.get

/**
 * Les deux routes HTTP de la lampe.
 *
 * @param baseUrl l'adresse de la lampe, définie dans build.gradle.kts (BuildConfig.LAMPE_URL)
 */
class LampeApi(private val client: HttpClient, private val baseUrl: String) {

    /** GET /status : l'état actuel, sans rien changer. */
    suspend fun statut(): StatutLampe = client.get("$baseUrl/status").body()

    /** GET /toggle : bascule la LED et renvoie le nouvel état. */
    suspend fun basculer(): StatutLampe = client.get("$baseUrl/toggle").body()
}
