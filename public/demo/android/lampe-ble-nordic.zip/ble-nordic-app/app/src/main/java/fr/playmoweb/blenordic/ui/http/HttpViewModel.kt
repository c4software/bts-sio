package fr.playmoweb.blenordic.ui.http

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import fr.playmoweb.blenordic.BuildConfig
import fr.playmoweb.blenordic.http.LampeApi
import fr.playmoweb.blenordic.http.createHttpClient
import fr.playmoweb.blenordic.model.EcranHttp
import fr.playmoweb.blenordic.model.StatutLampe
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Le ViewModel de l'écran Wi-Fi : il parle à la lampe en HTTP et expose l'état de l'écran.
 */
class HttpViewModel : ViewModel() {

    // Réel ou simulé selon la variante "native" / "mock" compilée
    private val client = createHttpClient()
    private val api = LampeApi(client, BuildConfig.LAMPE_URL)

    /** L'adresse de la lampe, affichée à l'écran. */
    val adresse: String = BuildConfig.LAMPE_URL

    private val _ecran = MutableStateFlow<EcranHttp>(EcranHttp.Chargement)
    val ecran: StateFlow<EcranHttp> = _ecran.asStateFlow()

    init {
        actualiser()
    }

    /** Lit l'état de la lampe (GET /status). */
    fun actualiser() = appeler { api.statut() }

    /** Bascule la LED (GET /toggle). */
    fun basculer() = appeler { api.basculer() }

    /** Lance une requête et fait passer l'écran par ses états : chargement, puis lampe ou erreur. */
    private fun appeler(requete: suspend () -> StatutLampe) {
        viewModelScope.launch {
            _ecran.value = EcranHttp.Chargement
            _ecran.value = try {
                EcranHttp.Lampe(requete())
            } catch (e: Exception) {
                EcranHttp.Erreur("La lampe ne répond pas sur $adresse : ${e.message}")
            }
        }
    }

    override fun onCleared() {
        client.close()
    }
}
