package fr.playmoweb.blenordic.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import fr.playmoweb.blenordic.ble.LampeGatt
import fr.playmoweb.blenordic.model.Appareil

/** Une ligne de la liste du scan. Les lampes (nom en PMW-) sont en gras. */
@Composable
fun AppareilItem(appareil: Appareil, onClick: () -> Unit) {
    val estUneLampe = appareil.nom.startsWith(LampeGatt.NAME_PREFIX)
    ListItem(
        headlineContent = {
            Text(appareil.nom, fontWeight = if (estUneLampe) FontWeight.Bold else FontWeight.Normal)
        },
        supportingContent = { Text(appareil.adresse) },
        modifier = Modifier.clickable(onClick = onClick),
    )
    HorizontalDivider()
}
