package fr.playmoweb.blenordic

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import fr.playmoweb.blenordic.ble.LampeGatt
import fr.playmoweb.blenordic.ble.createCentralManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.filterIsInstance
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import no.nordicsemi.kotlin.ble.client.RemoteCharacteristic
import no.nordicsemi.kotlin.ble.client.RemoteServices
import no.nordicsemi.kotlin.ble.client.android.CentralManager
import no.nordicsemi.kotlin.ble.client.android.Peripheral
import no.nordicsemi.kotlin.ble.client.distinctByPeripheral
import no.nordicsemi.kotlin.ble.core.ConnectionState
import kotlin.time.Duration.Companion.seconds

/** Un appareil trouvé pendant le scan. */
data class Appareil(val nom: String, val adresse: String, val peripheral: Peripheral)

/** Les écrans possibles de l'application. */
sealed interface Ecran {
    data object Scan : Ecran
    data class Connexion(val nom: String) : Ecran
    data class Connecte(
        val nom: String,
        val ledAllumee: Boolean? = null, // null tant qu'aucune notification n'est reçue
        val compteur: Int? = null,
    ) : Ecran
}

class LampeViewModel(application: Application) : AndroidViewModel(application) {

    // Point d'entrée de la bibliothèque Nordic : scan et connexion.
    // (Réel ou simulé selon la variante "native" / "mock" compilée.)
    private val centralManager: CentralManager = createCentralManager(application, viewModelScope)

    private val _ecran = MutableStateFlow<Ecran>(Ecran.Scan)
    val ecran: StateFlow<Ecran> = _ecran.asStateFlow()

    private val _appareils = MutableStateFlow<List<Appareil>>(emptyList())
    val appareils: StateFlow<List<Appareil>> = _appareils.asStateFlow()

    private val _scanEnCours = MutableStateFlow(false)
    val scanEnCours: StateFlow<Boolean> = _scanEnCours.asStateFlow()

    private val _erreur = MutableStateFlow<String?>(null)
    val erreur: StateFlow<String?> = _erreur.asStateFlow()

    private var scanJob: Job? = null
    private var connexionJob: Job? = null

    // Caractéristiques de la lampe connectée (trouvées après la découverte des services).
    private var peripheralConnecte: Peripheral? = null
    private var toggleLed: RemoteCharacteristic? = null
    private var deviceName: RemoteCharacteristic? = null

    // ---------------------------------------------------------------- Scan

    fun demarrerScan() {
        _appareils.value = emptyList()
        _erreur.value = null
        scanJob = centralManager
            .scan(10.seconds) {
                // Décommenter pour ne garder que les lampes :
                // Name(Regex("${LampeGatt.NAME_PREFIX}.*"))
            }
            .distinctByPeripheral() // un seul résultat par appareil
            .onStart { _scanEnCours.value = true }
            .onEach { resultat ->
                val appareil = Appareil(
                    nom = resultat.advertisingData.name ?: resultat.peripheral.name ?: "(sans nom)",
                    adresse = resultat.peripheral.address,
                    peripheral = resultat.peripheral,
                )
                _appareils.update { liste -> liste + appareil }
            }
            .catch { e -> _erreur.value = "Échec du scan : ${e.message}" }
            .onCompletion { _scanEnCours.value = false } // fin des 10 s ou arrêt manuel
            .launchIn(viewModelScope)
    }

    fun arreterScan() {
        scanJob?.cancel()
    }

    // ----------------------------------------------------------- Connexion

    fun connecter(appareil: Appareil) {
        arreterScan()
        _erreur.value = null
        _ecran.value = Ecran.Connexion(appareil.nom)

        connexionJob = viewModelScope.launch {
            val peripheral = appareil.peripheral
            try {
                // 1. Connexion directe (échoue après le délai si l'appareil ne répond pas).
                centralManager.connect(
                    peripheral = peripheral,
                    options = CentralManager.ConnectionOptions.Direct(timeout = 10.seconds, retry = 2),
                )

                // 2. Découverte des services : on attend l'état "Discovered".
                val services = withTimeout(10.seconds) {
                    peripheral.services(listOf(LampeGatt.SERVICE))
                        .filterIsInstance<RemoteServices.Discovered>()
                        .first()
                        .services
                }
                val service = services.firstOrNull { it.uuid == LampeGatt.SERVICE }
                    ?: error("Service de la lampe introuvable : est-ce bien une lampe ?")

                // 3. Recherche des caractéristiques par UUID.
                fun caracteristique(uuid: kotlin.uuid.Uuid) =
                    service.characteristics.firstOrNull { it.uuid == uuid }
                        ?: error("Caractéristique $uuid introuvable")

                toggleLed = caracteristique(LampeGatt.TOGGLE_LED)
                deviceName = caracteristique(LampeGatt.DEVICE_NAME)
                val ledState = caracteristique(LampeGatt.LED_STATE)
                val toggleCount = caracteristique(LampeGatt.TOGGLE_COUNT)

                peripheralConnecte = peripheral
                _ecran.value = Ecran.Connecte(nom = appareil.nom)

                // 4. Abonnement aux notifications (chaque flux tourne dans sa propre coroutine).
                ledState.subscribe()
                    .onEach { octets ->
                        val allumee = octets.decodeToString() == "1"
                        majConnecte { it.copy(ledAllumee = allumee) }
                    }
                    .launchIn(this)

                toggleCount.subscribe()
                    .onEach { octets ->
                        val compteur = octets.decodeToString().toIntOrNull()
                        majConnecte { it.copy(compteur = compteur) }
                    }
                    .launchIn(this)

                // 5. On reste ici jusqu'à la déconnexion (volontaire ou perte de liaison).
                peripheral.state.first { it is ConnectionState.Disconnected }
            } catch (e: Exception) {
                _erreur.value = "Connexion impossible : ${e.message}"
                peripheral.disconnect()
            }
            // Retour à l'écran de scan.
            peripheralConnecte = null
            toggleLed = null
            deviceName = null
            _ecran.value = Ecran.Scan
            connexionJob?.cancel() // arrête aussi les abonnements
        }
    }

    // --------------------------------------------------- Actions sur la lampe

    fun basculerLed() {
        val caracteristique = toggleLed ?: return
        viewModelScope.launch {
            try {
                caracteristique.write("1".encodeToByteArray())
            } catch (e: Exception) {
                _erreur.value = "Écriture impossible : ${e.message}"
            }
        }
    }

    fun renommer(nouveauNom: String) {
        val caracteristique = deviceName ?: return
        viewModelScope.launch {
            try {
                caracteristique.write(nouveauNom.encodeToByteArray())
            } catch (e: Exception) {
                _erreur.value = "Renommage impossible : ${e.message}"
            }
        }
    }

    fun deconnecter() {
        val peripheral = peripheralConnecte ?: return
        viewModelScope.launch {
            peripheral.disconnect()
        }
    }

    /** Modifie l'état de l'écran "connecté" (sans effet si on n'y est pas). */
    private fun majConnecte(modification: (Ecran.Connecte) -> Ecran.Connecte) {
        _ecran.update { ecran -> if (ecran is Ecran.Connecte) modification(ecran) else ecran }
    }

    override fun onCleared() {
        centralManager.close()
    }
}
