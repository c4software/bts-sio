package fr.playmoweb.blenordic

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import fr.playmoweb.blenordic.ui.ConnectedScreen
import fr.playmoweb.blenordic.ui.ConnectingScreen
import fr.playmoweb.blenordic.ui.PermissionsScreen
import fr.playmoweb.blenordic.ui.ScanScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF1565C0))) {
                LampeApp()
            }
        }
    }
}

/** Permissions nécessaires au BLE, selon la version d'Android. */
private val permissionsBle: List<String> =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        listOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun LampeApp(viewModel: LampeViewModel = viewModel()) {
    val permissions = rememberMultiplePermissionsState(permissionsBle)

    // Les StateFlow du ViewModel deviennent des états Compose.
    val ecran by viewModel.ecran.collectAsStateWithLifecycle()
    val appareils by viewModel.appareils.collectAsStateWithLifecycle()
    val scanEnCours by viewModel.scanEnCours.collectAsStateWithLifecycle()
    val erreur by viewModel.erreur.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lampe connectée") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            if (!permissions.allPermissionsGranted) {
                PermissionsScreen(onDemander = { permissions.launchMultiplePermissionRequest() })
            } else {
                when (val e = ecran) {
                    Ecran.Scan -> ScanScreen(
                        appareils = appareils,
                        scanEnCours = scanEnCours,
                        erreur = erreur,
                        onScan = viewModel::demarrerScan,
                        onStop = viewModel::arreterScan,
                        onClicAppareil = viewModel::connecter,
                    )
                    is Ecran.Connexion -> ConnectingScreen(nom = e.nom)
                    is Ecran.Connecte -> ConnectedScreen(
                        etat = e,
                        erreur = erreur,
                        onBasculer = viewModel::basculerLed,
                        onRenommer = viewModel::renommer,
                        onDeconnecter = viewModel::deconnecter,
                    )
                }
            }
        }
    }
}
