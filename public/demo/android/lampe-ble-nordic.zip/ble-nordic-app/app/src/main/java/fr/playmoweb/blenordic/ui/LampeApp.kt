package fr.playmoweb.blenordic.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import fr.playmoweb.blenordic.ui.ble.BleScreen
import fr.playmoweb.blenordic.ui.http.HttpScreen

/** Les deux façons de parler à la lampe, une par onglet. */
private enum class Onglet(val route: String, val titre: String, val icone: ImageVector) {
    BLUETOOTH("ble", "Bluetooth", Icons.Filled.Bluetooth),
    WIFI("http", "Wi-Fi (HTTP)", Icons.Filled.Wifi),
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LampeApp() {
    val navController = rememberNavController()
    val routeCourante by navController.currentBackStackEntryAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lampe connectée") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                ),
            )
        },
        bottomBar = {
            NavigationBar {
                Onglet.entries.forEach { onglet ->
                    NavigationBarItem(
                        selected = routeCourante?.destination?.route == onglet.route,
                        onClick = {
                            navController.navigate(onglet.route) {
                                // Un seul exemplaire de chaque onglet dans la pile de navigation
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(onglet.icone, contentDescription = null) },
                        label = { Text(onglet.titre) },
                    )
                }
            }
        },
    ) { padding ->
        Box(Modifier.padding(padding)) {
            NavHost(navController = navController, startDestination = Onglet.BLUETOOTH.route) {
                composable(Onglet.BLUETOOTH.route) { BleScreen() }
                composable(Onglet.WIFI.route) { HttpScreen() }
            }
        }
    }
}
