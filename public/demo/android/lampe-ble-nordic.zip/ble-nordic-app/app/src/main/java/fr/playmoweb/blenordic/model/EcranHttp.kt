package fr.playmoweb.blenordic.model

/**
 * La machine à états de l'écran Wi-Fi (HTTP).
 *
 * La vue fait un `when` sur cet état : à chaque état, son composant.
 */
sealed interface EcranHttp {
    /** Requête en cours (loader). */
    data object Chargement : EcranHttp

    /** La lampe a répondu. */
    data class Lampe(val statut: StatutLampe) : EcranHttp

    /** La lampe ne répond pas (mauvaise adresse, pas sur le même réseau…). */
    data class Erreur(val message: String) : EcranHttp
}
