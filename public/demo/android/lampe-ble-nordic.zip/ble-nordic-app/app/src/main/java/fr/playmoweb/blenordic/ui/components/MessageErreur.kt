package fr.playmoweb.blenordic.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

/** Une erreur à afficher, ou rien si tout va bien. */
@Composable
fun MessageErreur(message: String?) {
    if (message != null) {
        Text(message, color = MaterialTheme.colorScheme.error)
    }
}
