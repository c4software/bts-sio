package fr.playmoweb.blenordic.http

import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

/**
 * Variante "native" : un vrai client HTTP (moteur OkHttp), qui parle à la lampe sur le réseau.
 */
fun createHttpClient(): HttpClient = HttpClient(OkHttp) {
    // Les réponses JSON deviennent directement des objets Kotlin (StatutLampe)
    install(ContentNegotiation) {
        json(Json { ignoreUnknownKeys = true })
    }
    // Une lampe injoignable ne doit pas bloquer l'écran trop longtemps
    install(HttpTimeout) {
        requestTimeoutMillis = 5_000
    }
}
