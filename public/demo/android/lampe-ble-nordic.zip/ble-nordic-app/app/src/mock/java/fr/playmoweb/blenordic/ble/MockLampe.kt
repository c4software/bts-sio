package fr.playmoweb.blenordic.ble

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import no.nordicsemi.kotlin.ble.client.mock.ConnectionResult
import no.nordicsemi.kotlin.ble.client.mock.PeripheralSpec
import no.nordicsemi.kotlin.ble.client.mock.PeripheralSpecEventHandler
import no.nordicsemi.kotlin.ble.client.mock.Proximity
import no.nordicsemi.kotlin.ble.client.mock.WriteResponse
import no.nordicsemi.kotlin.ble.client.mock.internal.MockRemoteCharacteristic
import no.nordicsemi.kotlin.ble.client.mock.internal.MockRemoteDescriptor
import no.nordicsemi.kotlin.ble.core.CharacteristicProperty
import no.nordicsemi.kotlin.ble.core.LegacyAdvertisingSetParameters
import no.nordicsemi.kotlin.ble.core.Permission
import no.nordicsemi.kotlin.ble.core.PrimaryPhy
import kotlin.time.Duration.Companion.milliseconds

/**
 * Lampe connectée simulée : reproduit le comportement du firmware ESP32.
 *
 * - toute écriture sur TOGGLE_LED bascule la LED (comme le firmware), puis notifie LED_STATE et TOGGLE_COUNT ;
 * - écrire un texte sur DEVICE_NAME change le nom (simplement mémorisé ici).
 */
class MockLampe(private val scope: CoroutineScope) {

    private var ledAllumee = false
    private var compteur = 0
    private var nom = "PMW-1A2B"

    // Numéros (handles) des caractéristiques notifiables, attribués à la création du service.
    private var ledStateHandle = -1
    private var toggleCountHandle = -1

    private val comportement = object : PeripheralSpecEventHandler {

        override fun onConnectionRequest(phy: PrimaryPhy): ConnectionResult = ConnectionResult.Accept

        override fun onReset() {
            ledAllumee = false
            compteur = 0
        }

        // Écriture d'une caractéristique (avec réponse).
        override fun onWriteRequest(characteristic: MockRemoteCharacteristic, value: ByteArray): WriteResponse {
            val texte = value.decodeToString()
            when (characteristic.uuid) {
                LampeGatt.TOGGLE_LED -> {
                    // Comme le firmware : toute écriture bascule la LED, quelle que soit la valeur
                    ledAllumee = !ledAllumee
                    compteur++
                    notifierEtat()
                }
                // Comme la lampe : le préfixe PMW- est ajouté s'il manque
                LampeGatt.DEVICE_NAME -> nom = if (texte.startsWith(LampeGatt.NAME_PREFIX)) texte else LampeGatt.NAME_PREFIX + texte
            }
            return WriteResponse.Success
        }

        // Écriture d'un descripteur : ici, l'activation des notifications (CCCD).
        // Comme une vraie lampe, on envoie l'état courant dès qu'un client s'abonne.
        override fun onWriteRequest(descriptor: MockRemoteDescriptor, value: ByteArray): WriteResponse {
            scope.launch {
                delay(100.milliseconds) // laisse le temps à l'abonnement de s'établir
                notifierEtat()
            }
            return WriteResponse.Success
        }
    }

    private fun notifierEtat() {
        spec.simulateValueUpdate(ledStateHandle, (if (ledAllumee) "1" else "0").encodeToByteArray())
        spec.simulateValueUpdate(toggleCountHandle, compteur.toString().encodeToByteArray())
    }

    val spec: PeripheralSpec<String> = PeripheralSpec.simulatePeripheral(
        identifier = "24:6F:28:1A:2B:3C",
        proximity = Proximity.IMMEDIATE,
    ) {
        advertising(
            // Intervalle volontairement long (comme un ESP32 économe) :
            // la connexion attend la prochaine annonce, ce qui rend le "loader" visible.
            parameters = LegacyAdvertisingSetParameters(connectable = true, interval = 1500.milliseconds),
            delay = 800.milliseconds,
        ) {
            CompleteLocalName(nom)
        }
        connectable(
            name = nom,
            eventHandler = comportement,
        ) {
            GenericAccessService()
            GenericAttributeService()
            Service(uuid = LampeGatt.SERVICE) {
                Characteristic(
                    uuid = LampeGatt.TOGGLE_LED,
                    properties = setOf(CharacteristicProperty.WRITE),
                    permission = Permission.WRITE,
                )
                ledStateHandle = Characteristic(
                    uuid = LampeGatt.LED_STATE,
                    properties = setOf(CharacteristicProperty.NOTIFY),
                    permissions = emptySet(),
                ) // le descripteur CCCD est ajouté automatiquement
                toggleCountHandle = Characteristic(
                    uuid = LampeGatt.TOGGLE_COUNT,
                    properties = setOf(CharacteristicProperty.NOTIFY),
                    permissions = emptySet(),
                )
                Characteristic(
                    uuid = LampeGatt.DEVICE_NAME,
                    properties = setOf(CharacteristicProperty.WRITE),
                    permission = Permission.WRITE,
                )
            }
        }
    }
}
