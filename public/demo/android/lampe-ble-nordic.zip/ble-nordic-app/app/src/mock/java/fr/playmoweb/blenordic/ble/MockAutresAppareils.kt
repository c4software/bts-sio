package fr.playmoweb.blenordic.ble

import no.nordicsemi.kotlin.ble.client.mock.PeripheralSpec
import no.nordicsemi.kotlin.ble.client.mock.Proximity
import no.nordicsemi.kotlin.ble.core.LegacyAdvertisingSetParameters
import kotlin.time.Duration.Companion.milliseconds

/**
 * Appareils "parasites" simulés, pour que la liste du scan ressemble à la réalité.
 * Ils ne sont pas connectables et n'implémentent aucun service.
 */
object MockAutresAppareils {

    fun enceinte() = PeripheralSpec.simulatePeripheral(
        identifier = "C4:7E:21:9A:03:5D",
        proximity = Proximity.NEAR,
    ) {
        advertising(
            parameters = LegacyAdvertisingSetParameters(connectable = false, interval = 300.milliseconds),
            delay = 400.milliseconds,
        ) {
            CompleteLocalName("JBL Flip 5")
        }
    }

    fun capteur() = PeripheralSpec.simulatePeripheral(
        identifier = "E2:11:5B:C0:7F:42",
        proximity = Proximity.FAR,
    ) {
        advertising(
            parameters = LegacyAdvertisingSetParameters(connectable = false, interval = 500.milliseconds),
            delay = 1200.milliseconds,
        ) {
            CompleteLocalName("Mi Temp 2")
        }
    }
}
