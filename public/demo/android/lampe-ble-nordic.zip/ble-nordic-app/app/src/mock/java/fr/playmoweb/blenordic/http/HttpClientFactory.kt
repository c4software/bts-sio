package fr.playmoweb.blenordic.http

import io.ktor.client.HttpClient
import io.ktor.client.engine.mock.MockEngine
import io.ktor.client.engine.mock.respond
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.http.ContentType
import io.ktor.http.HttpHeaders
import io.ktor.http.HttpStatusCode
import io.ktor.http.headersOf
import io.ktor.serialization.kotlinx.json.json
import kotlinx.coroutines.delay
import kotlinx.serialization.json.Json

/**
 * Variante "mock" : une lampe simulée qui répond comme la vraie, sans réseau (MockEngine de Ktor).
 */
fun createHttpClient(): HttpClient {
    var ledAllumee = false
    var compteur = 0

    val lampeSimulee = MockEngine { requete ->
        delay(400) // un peu de latence, pour voir le loader
        when (requete.url.encodedPath) {
            "/toggle" -> { ledAllumee = !ledAllumee; compteur++ }
            "/status" -> Unit
            else -> return@MockEngine respond("""{"error":"not found"}""", HttpStatusCode.NotFound)
        }
        val etat = if (ledAllumee) "ON" else "OFF"
        respond(
            content = """{"state":"$etat","count":$compteur}""",
            status = HttpStatusCode.OK,
            headers = headersOf(HttpHeaders.ContentType, ContentType.Application.Json.toString()),
        )
    }

    return HttpClient(lampeSimulee) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }
}
