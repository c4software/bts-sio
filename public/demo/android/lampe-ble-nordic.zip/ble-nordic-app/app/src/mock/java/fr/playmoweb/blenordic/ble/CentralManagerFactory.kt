package fr.playmoweb.blenordic.ble

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import no.nordicsemi.kotlin.ble.client.android.CentralManager
import no.nordicsemi.kotlin.ble.client.android.mock.mock

/**
 * Variante "mock" : crée un CentralManager simulé (aucun vrai Bluetooth n'est utilisé).
 *
 * Le scan "trouve" une lampe simulée PMW-1A2B et deux autres appareils sans rapport.
 */
@Suppress("UNUSED_PARAMETER") // même signature que la variante native
fun createCentralManager(context: Context, scope: CoroutineScope): CentralManager =
    CentralManager.mock(scope = scope).apply {
        simulatePeripherals(
            listOf(
                MockLampe(scope).spec,
                MockAutresAppareils.enceinte(),
                MockAutresAppareils.capteur(),
            )
        )
    }
