pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral() // La bibliothèque Nordic est publiée sur Maven Central.
    }
}

rootProject.name = "BleNordicApp"
include(":app")
