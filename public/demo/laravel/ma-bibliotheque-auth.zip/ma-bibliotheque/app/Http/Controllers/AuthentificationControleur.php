<?php

namespace App\Http\Controllers;

use App\Models\Membre;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthentificationControleur extends Controller
{
    /**
     * Affiche le formulaire de connexion.
     */
    public function login()
    {
        return view('login');
    }

    /**
     * Affiche le formulaire d'inscription.
     */
    public function register()
    {
        return view('register');
    }

    /**
     * Traite le formulaire d'inscription.
     */
    public function traitementRegister(Request $request)
    {
        // Un email ne peut être utilisé qu'une seule fois
        if (Membre::where('email', $request->input('email'))->exists()) {
            return redirect('/register')
                ->withInput($request->only('pseudo', 'email')) // Jamais le mot de passe !
                ->withErrors(['email' => 'Cet email est déjà utilisé']);
        }

        // On stocke le HASH du mot de passe, jamais le mot de passe en clair
        $hash = password_hash($request->input('password'), PASSWORD_DEFAULT);

        Membre::create([
            'pseudo' => $request->input('pseudo'),
            'email' => $request->input('email'),
            'password' => $hash,
        ]);

        return redirect('/login')->with('success', 'Votre compte a été créé, vous pouvez vous connecter');
    }

    /**
     * Traite le formulaire de connexion.
     */
    public function traitementLogin(Request $request)
    {
        $membre = Membre::where('email', $request->input('email'))->first();

        // Email inconnu : même message qu'un mauvais mot de passe
        if ($membre === null) {
            return $this->identifiantsIncorrects($request);
        }

        $estValide = password_verify($request->input('password'), $membre->password);

        if ($estValide) {
            // Ouvre la session du membre (il est maintenant « connecté »)
            Auth::login($membre);
            // Génère un nouvel identifiant de session (protection contre la fixation de session)
            $request->session()->regenerate();

            return redirect('/livres');
        }

        return $this->identifiantsIncorrects($request);
    }

    /**
     * Déconnecte le membre.
     */
    public function logout()
    {
        Auth::logout();

        return redirect('/login');
    }

    /**
     * Retour au formulaire de connexion, avec l'email conservé.
     */
    private function identifiantsIncorrects(Request $request)
    {
        return redirect('/login')
            ->withInput($request->only('email'))
            ->withErrors(['email' => 'Identifiants incorrects']);
    }
}
