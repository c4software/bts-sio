<?php

use App\Http\Controllers\ChatController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PersonneController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\YoloController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', [DashboardController::class, 'index'])->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/yolo', [YoloController::class, 'publicView']);
Route::get('/yolo-connected', [YoloController::class, 'privateView'])->middleware(['auth'])->name('yoloPrivate');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/personnes', [PersonneController::class, 'index'])->name('personnes');
    Route::get('/personne/{personne}', [PersonneController::class, 'show'])->name('personne');

    Route::get('/roles', [DashboardController::class, 'roles'])->name('roles');
    Route::post('/glow-up', [DashboardController::class, 'glowUpAsAdmin'])->name('glowUp');

    Route::get('/chat', [ChatController::class, 'index'])->name('chat');
    Route::get('/getMessages', [ChatController::class, 'getMessages'])->name('chat.messages');
    Route::post('/sendMessage', [ChatController::class, 'store'])->name('chat.store');
    Route::delete('/message/{message}', [ChatController::class, 'destroy'])->name('chat.destroy');
});

require __DIR__.'/auth.php';
