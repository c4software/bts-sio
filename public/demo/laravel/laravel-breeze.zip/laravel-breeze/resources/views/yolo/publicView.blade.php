<x-guest-layout>
    <div class="text-center font-bold text-indigo-600">Bonjour Mr Anonyme 👋</div>
</x-guest-layout>
