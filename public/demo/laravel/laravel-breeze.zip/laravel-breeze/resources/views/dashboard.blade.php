<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid gap-4 md:grid-cols-2 mb-6">
                <x-stat titre="Personnes inscrites" :valeur="$nbPersonnes" />
                <x-stat titre="Messages dans le chat" :valeur="$nbMessages" />
            </div>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <p class="font-bold mb-2">Bonjour {{ Auth::user()->pseudo }} 👋</p>

                    @if ($personne)
                        <ul class="list-disc ms-6">
                            <li>Ville : {{ $personne->ville }}</li>
                            <li>Date de naissance : {{ \Carbon\Carbon::parse($personne->date_naissance)->format('d/m/Y') }}</li>
                            <li>Genre : {{ $personne->genre }}</li>
                        </ul>
                    @else
                        <p>Aucune information complémentaire.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
