<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Mes rôles</h2>
    </x-slot>

    <x-card>
        <ul class="list-disc ms-6 mb-4">
            @forelse ($roles as $role)
                <li>{{ $role->name }}</li>
            @empty
                <li>Aucun rôle</li>
            @endforelse
        </ul>

        <form method="POST" action="{{ route('glowUp') }}">
            @csrf
            <x-primary-button>Devenir administrateur 🚀</x-primary-button>
        </form>
    </x-card>
</x-app-layout>
