<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Les personnes</h2>
    </x-slot>

    <x-card>
        <ul class="divide-y">
            @foreach ($personnes as $personne)
                <li class="py-2">
                    <a class="text-indigo-600 underline" href="{{ route('personne', $personne) }}">{{ $personne->user->name }}</a>
                    ({{ $personne->ville }})
                </li>
            @endforeach
        </ul>
    </x-card>
</x-app-layout>
