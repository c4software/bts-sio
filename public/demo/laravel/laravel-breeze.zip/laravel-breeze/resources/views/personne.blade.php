<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">{{ $personne->user->name }}</h2>
    </x-slot>

    <x-card>
        <ul class="list-disc ms-6">
            <li>Pseudo : {{ $personne->user->pseudo }}</li>
            <li>Ville : {{ $personne->ville }}</li>
            <li>Date de naissance : {{ \Carbon\Carbon::parse($personne->date_naissance)->format('d/m/Y') }}</li>
            <li>Genre : {{ $personne->genre }}</li>
        </ul>
    </x-card>
</x-app-layout>
