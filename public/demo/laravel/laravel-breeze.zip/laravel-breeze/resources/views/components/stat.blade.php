@props(['titre', 'valeur'])

<article class="flex items-end justify-between rounded-lg border border-gray-100 bg-white p-6">
  <div>
    <p class="text-sm text-gray-500">{{ $titre }}</p>

    <p class="text-2xl font-medium text-gray-900">{{ $valeur }}</p>
  </div>
</article>
