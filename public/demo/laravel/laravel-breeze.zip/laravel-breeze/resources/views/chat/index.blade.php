<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Chat</h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-sm sm:rounded-lg p-6">
                <div id="messages" hx-get="{{ route('chat.messages') }}" hx-trigger="every 2s">
                    @include('chat.messages')
                </div>

                <form class="mt-4 flex gap-2" method="POST" action="{{ route('chat.store') }}"
                      hx-post="{{ route('chat.store') }}" hx-target="#messages" hx-swap="innerHTML"
                      hx-on::after-request="this.reset()">
                    @csrf
                    <x-text-input name="message" class="flex-1" placeholder="Votre message" required />
                    <x-primary-button>Envoyer</x-primary-button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://unpkg.com/htmx.org@2.0.11"></script>
</x-app-layout>
