@forelse ($messages as $message)
    <div class="message border-b py-2">
        <div class="flex justify-between text-sm text-gray-500">
            <span class="user font-semibold text-gray-800">{{ $message->user->name }}</span>
            <span>{{ $message->created_at->format('d/m/Y H:i') }}</span>
        </div>
        <div class="content">{{ $message->contenu }}</div>

        @if (Auth::user()->isAdmin())
            <form method="POST" action="{{ route('chat.destroy', $message) }}">
                @csrf
                @method('DELETE')
                <button class="text-xs text-red-600 underline">Supprimer</button>
            </form>
        @endif
    </div>
@empty
    <p class="text-gray-500">Aucun message pour l'instant.</p>
@endforelse
