<?php

namespace Tests\Feature\Auth;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RegistrationTest extends TestCase
{
    use RefreshDatabase;

    public function test_registration_screen_can_be_rendered(): void
    {
        $response = $this->get('/register');

        $response->assertStatus(200);
    }

    public function test_new_users_can_register(): void
    {
        $this->seed();

        $response = $this->post('/register', [
            'name' => 'Test User',
            'email' => 'nouveau@example.com',
            'password' => 'password',
            'password_confirmation' => 'password',
            'pseudo' => 'testeur',
            'ville' => 'Angers',
            'date_naissance' => '2005-03-14',
            'genre' => 'Non précisé',
        ]);

        $this->assertAuthenticated();
        $response->assertRedirect(route('dashboard', absolute: false));
    }
}
