<?php

namespace App\Http\Controllers;

use App\Models\Message;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatController extends Controller
{
    public function index()
    {
        return view('chat.index', ['messages' => $this->derniersMessages()]);
    }

    public function getMessages()
    {
        return view('chat.messages', ['messages' => $this->derniersMessages()]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'message' => ['required', 'string', 'max:500'],
        ]);

        Message::create([
            'contenu' => $request->message,
            'user_id' => Auth::id(),
        ]);

        // Appel Ajax (HTMX) : on renvoie uniquement la liste des messages
        if ($request->header('HX-Request')) {
            return $this->getMessages();
        }

        return redirect()->route('chat');
    }

    public function destroy(Message $message)
    {
        if (! Auth::user()->isAdmin()) {
            abort(403);
        }

        $message->delete();

        return redirect()->route('chat');
    }

    private function derniersMessages()
    {
        return Message::with('user')->orderBy('created_at')->get();
    }
}
