<?php

namespace App\Http\Controllers;

class YoloController extends Controller
{
    public function publicView()
    {
        return view('yolo.publicView');
    }

    public function privateView()
    {
        return view('yolo.privateView');
    }
}
