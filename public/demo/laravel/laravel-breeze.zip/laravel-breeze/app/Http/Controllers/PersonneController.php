<?php

namespace App\Http\Controllers;

use App\Models\Personne;

class PersonneController extends Controller
{
    public function index()
    {
        $personnes = Personne::with('user')->get();

        return view('personnes', ['personnes' => $personnes]);
    }

    public function show(Personne $personne)
    {
        return view('personne', ['personne' => $personne]);
    }
}
