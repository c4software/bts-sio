<?php

namespace App\Http\Controllers;

use App\Models\Role;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $personne = Auth::user()->personne;

        return view('dashboard', ['personne' => $personne]);
    }

    public function roles()
    {
        $roles = Auth::user()->roles;

        return view('roles', ['roles' => $roles]);
    }

    public function glowUpAsAdmin()
    {
        $admin = Role::where('name', 'admin')->first();
        Auth::user()->roles()->sync([$admin->id]);

        return redirect()->route('roles');
    }
}
