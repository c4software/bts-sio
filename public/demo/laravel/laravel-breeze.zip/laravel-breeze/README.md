# L'authentification avec Breeze : le projet de référence

Code complet du TP [L'authentification avec Breeze](https://cours.brosseau.ovh/tp/laravel/authentification.html) (Laravel 13, Breeze 2.4, stack Blade).

Ce que contient le projet :

- L'authentification générée par Breeze, et la Laravel Debugbar.
- La page d'accueil migrée vers `<x-guest-layout>` et le composant `<x-card>`.
- Les pages `/yolo` (publique) et `/yolo-connected` (protégée par le middleware `auth`).
- L'inscription enrichie : pseudo, et une `Personne` (ville, date de naissance, genre) créée en même temps que l'utilisateur.
- Le `DashboardController`, les pages `/personnes` et `/personne/{personne}` (Route Model Binding).
- Les rôles (table pivot `role_user`), la page `/roles` et le « super bouton » pour devenir administrateur.
- Le chat (`/chat`) rafraîchi avec HTMX, la suppression des messages réservée aux administrateurs.

## Installation

```sh
cd laravel-breeze
composer install
cp .env.example .env
php artisan key:generate
php artisan migrate --seed
npm install
npm run build
php artisan serve
```

Si `migrate` vous demande de créer le fichier `database.sqlite`, répondez `yes`. Le `--seed` crée les rôles `admin` et `user` (ainsi qu'un compte `test@example.com` sans rôle) : créez votre propre compte sur `/register`.

Pendant le développement, `composer run dev` lance le serveur PHP et Vite en même temps.

## Les tests

```sh
php artisan test
```
