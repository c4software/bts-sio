<?php

use App\Http\Controllers\LivreControleur;
use Illuminate\Support\Facades\Route;

// La page d'accueil renvoie directement vers la liste des livres
Route::get('/', function () {
    return redirect('/livres');
});

Route::get('/livres', [LivreControleur::class, 'liste']);
Route::post('/livres', [LivreControleur::class, 'ajouter']);
