<x-layouts::auth title="Yolo">
    <div class="text-center font-bold text-indigo-600">Bonjour Mr Anonyme 👋</div>
</x-layouts::auth>
