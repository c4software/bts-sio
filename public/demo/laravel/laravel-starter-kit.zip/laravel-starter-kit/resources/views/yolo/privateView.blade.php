<x-layouts::app title="Yolo">
    <flux:heading size="xl" class="mb-6">Hello</flux:heading>

    <x-card>
        <div class="text-center font-bold text-indigo-600">
            Bonjour {{ Auth::user()->name }} 👋
        </div>
    </x-card>
</x-layouts::app>
