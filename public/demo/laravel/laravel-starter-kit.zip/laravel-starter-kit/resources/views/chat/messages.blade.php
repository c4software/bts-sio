@forelse ($messages as $message)
    <div class="border-b border-neutral-200 py-3 last:border-0 dark:border-neutral-700">
        <div class="flex items-center justify-between">
            <span class="font-semibold">{{ $message->user->name }}</span>
            <span class="text-xs text-neutral-500">{{ $message->created_at->format('d/m/Y H:i') }}</span>
        </div>

        <p class="mt-1">{{ $message->contenu }}</p>

        @if (Auth::user()->isAdmin())
            <form method="POST" action="{{ route('message.destroy', $message) }}" class="mt-1">
                @csrf
                @method('DELETE')
                <button type="submit" class="text-xs text-red-600 underline">Supprimer</button>
            </form>
        @endif
    </div>
@empty
    <p class="text-neutral-500">Aucun message pour l'instant.</p>
@endforelse
