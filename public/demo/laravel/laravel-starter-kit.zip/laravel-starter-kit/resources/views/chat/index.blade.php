<x-layouts::app title="Chat">
    <flux:heading size="xl" class="mb-6">Chat</flux:heading>

    <x-card>
        <div id="messages" hx-get="/getMessages" hx-trigger="every 2s">
            @include('chat.messages')
        </div>

        <form method="POST" action="/sendMessage" class="mt-6 flex gap-2"
              hx-post="/sendMessage" hx-target="#messages" hx-swap="innerHTML"
              hx-on::after-request="this.reset()">
            @csrf
            <flux:input name="message" placeholder="Votre message" required class="flex-1" />
            <flux:button type="submit" variant="primary">Envoyer</flux:button>
        </form>
    </x-card>

    <script src="https://unpkg.com/htmx.org@2.0.11"></script>
</x-layouts::app>
