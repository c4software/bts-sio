<x-layouts::app title="Mes rôles">
    <flux:heading size="xl" class="mb-6">Mes rôles</flux:heading>

    <x-card>
        <ul class="mb-6 list-inside list-disc">
            @foreach ($roles as $role)
                <li>{{ $role->name }}</li>
            @endforeach
        </ul>

        <form method="POST" action="{{ route('glowUp') }}">
            @csrf
            <flux:button type="submit" variant="primary">Devenir administrateur 🚀</flux:button>
        </form>
    </x-card>
</x-layouts::app>
