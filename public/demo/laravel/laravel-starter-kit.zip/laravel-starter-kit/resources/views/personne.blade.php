<x-layouts::app :title="$personne->user->name">
    <flux:heading size="xl" class="mb-6">{{ $personne->user->name }}</flux:heading>

    <x-card>
        <ul class="space-y-1">
            <li><strong>Ville :</strong> {{ $personne->ville }}</li>
            <li><strong>Date de naissance :</strong> {{ $personne->date_naissance }}</li>
            <li><strong>Genre :</strong> {{ $personne->genre }}</li>
        </ul>
    </x-card>
</x-layouts::app>
