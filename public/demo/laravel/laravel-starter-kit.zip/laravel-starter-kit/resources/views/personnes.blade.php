<x-layouts::app title="Personnes">
    <flux:heading size="xl" class="mb-6">Les personnes inscrites</flux:heading>

    <x-card>
        <ul class="divide-y divide-neutral-200 dark:divide-neutral-700">
            @foreach ($personnes as $personne)
                <li class="flex justify-between py-3">
                    <span>{{ $personne->user->name }} ({{ $personne->ville }})</span>
                    <flux:link :href="route('personne', $personne)" wire:navigate>Voir</flux:link>
                </li>
            @endforeach
        </ul>
    </x-card>
</x-layouts::app>
