<x-layouts::app :title="__('Dashboard')">
    <flux:heading size="xl" class="mb-6">Dashboard</flux:heading>

    <div class="mb-6 grid gap-4 md:grid-cols-2">
        <x-stat titre="Personnes inscrites" :valeur="$nbPersonnes" />
        <x-stat titre="Messages dans le chat" :valeur="$nbMessages" />
    </div>

    <x-card>
        @if ($personne)
            <flux:heading size="lg" class="mb-4">Mes informations</flux:heading>

            <ul class="space-y-1">
                <li><strong>Pseudo :</strong> {{ Auth::user()->pseudo }}</li>
                <li><strong>Ville :</strong> {{ $personne->ville }}</li>
                <li><strong>Date de naissance :</strong> {{ $personne->date_naissance }}</li>
                <li><strong>Genre :</strong> {{ $personne->genre }}</li>
            </ul>
        @else
            <p>Aucune information complémentaire pour ce compte.</p>
        @endif
    </x-card>
</x-layouts::app>
