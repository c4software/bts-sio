<?php

namespace App\Actions\Fortify;

use App\Concerns\PasswordValidationRules;
use App\Concerns\ProfileValidationRules;
use App\Models\Personne;
use App\Models\Role;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules, ProfileValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array<string, string>  $input
     */
    public function create(array $input): User
    {
        Validator::make($input, [
            ...$this->profileRules(),
            'password' => $this->passwordRules(),
            'pseudo' => ['required', 'string', 'max:50'],
            'ville' => ['required', 'string', 'max:100'],
            'date_naissance' => ['required', 'date', 'before:today'],
            'genre' => ['required', 'string', 'max:50'],
        ])->validate();

        $user = User::create([
            'name' => $input['name'],
            'pseudo' => $input['pseudo'],
            'email' => $input['email'],
            'password' => $input['password'],
        ]);

        Personne::create([
            'ville' => $input['ville'],
            'date_naissance' => $input['date_naissance'],
            'genre' => $input['genre'],
            'user_id' => $user->id,
        ]);

        // Rôle « user » par défaut
        $user->roles()->attach(Role::where('name', 'user')->first());

        return $user;
    }
}
