<?php

use App\Http\Controllers\ChatController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PersonneController;
use App\Http\Controllers\YoloController;
use Illuminate\Support\Facades\Route;

Route::view('/', 'welcome')->name('home');

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
});

Route::get('/yolo', [YoloController::class, 'publicView']);
Route::get('/yolo-connected', [YoloController::class, 'privateView'])->middleware(['auth'])->name('yoloPrivate');

Route::get('/personnes', [PersonneController::class, 'index'])->middleware(['auth'])->name('personnes');
Route::get('/personne/{personne}', [PersonneController::class, 'show'])->middleware(['auth'])->name('personne');

Route::get('/roles', [DashboardController::class, 'roles'])->middleware(['auth'])->name('roles');
Route::post('/glow-up', [DashboardController::class, 'glowUpAsAdmin'])->middleware(['auth'])->name('glowUp');

Route::get('/chat', [ChatController::class, 'index'])->middleware(['auth'])->name('chat');
Route::get('/getMessages', [ChatController::class, 'getMessages'])->middleware(['auth']);
Route::post('/sendMessage', [ChatController::class, 'store'])->middleware(['auth']);
Route::delete('/message/{message}', [ChatController::class, 'destroy'])->middleware(['auth'])->name('message.destroy');

require __DIR__.'/settings.php';
